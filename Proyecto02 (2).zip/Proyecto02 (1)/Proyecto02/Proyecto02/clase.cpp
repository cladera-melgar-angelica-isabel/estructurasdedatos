#include "StdAfx.h"
#include "clase.h"


clase::clase(void)
{
	matriz[t][t]=0;
	matriz1[t][t]=" ";
	tamano=0;
}
void clase::Insertar(int elemento, int fila, int columna)
{	
	matriz[fila][columna]=elemento;
	tamano++;
}

void clase::Mostrar(int &elemento, int fila, int columna)
{
	elemento=matriz[fila][columna];
}

void clase::Insertar(float elemento, int fila, int columna)
{	
	matriz2[fila][columna]=elemento;
	tamano++;
}

void clase::Mostrar(float &elemento, int fila, int columna)
{
	elemento=matriz2[fila][columna];
}

void clase::Insertar(string elemento, int fila, int columna)
{	
	matriz1[fila][columna]=elemento;
	tamano++;
}

void clase::Mostrar(string &elemento, int fila, int columna)
{
	elemento=matriz1[fila][columna];
}


int  clase::Get_tamano()
{
return tamano;
}