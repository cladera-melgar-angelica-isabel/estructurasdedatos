#pragma once
#include <iostream>
#include <string>
using namespace std;
#define t 10
 class clase
{
private:
	int matriz[t][t];
	float matriz2[t][t];
	string matriz1[t][t];
	int tamano;
public:
	clase(void);
	void Insertar(int elemento, int fila, int columna);
	void Mostrar(int &elemento, int fila, int columna);

	void Insertar(float elemento, int fila, int columna);
	void Mostrar(float &elemento, int fila, int columna);

	void Insertar(string elemento, int fila, int columna);
	void Mostrar(string &elemento, int fila, int columna);

	int Get_tamano();
};

