#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "clase.h"
using namespace std;
using namespace msclr::interop;
using namespace System::Windows::Forms;

namespace Proyecto02 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Form1
	/// </summary>
	clase preguntas, enfermedades, puntos, porcentaje;
	int i=0, n=0, lim=0,std=0;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  Grilla;
	protected: 



	private: System::Windows::Forms::TextBox^  txtPreguntas;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->Grilla = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txtPreguntas = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->BeginInit();
			this->SuspendLayout();
			// 
			// Grilla
			// 
			this->Grilla->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grilla->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(3) {this->Column1, this->Column2, 
				this->Column3});
			this->Grilla->Location = System::Drawing::Point(78, 203);
			this->Grilla->Name = L"Grilla";
			this->Grilla->Size = System::Drawing::Size(341, 221);
			this->Grilla->TabIndex = 0;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Enfermedad";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Porcentaje%";
			this->Column2->Name = L"Column2";
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"";
			this->Column3->Name = L"Column3";
			// 
			// txtPreguntas
			// 
			this->txtPreguntas->Font = (gcnew System::Drawing::Font(L"Arial", 11.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->txtPreguntas->Location = System::Drawing::Point(78, 131);
			this->txtPreguntas->Name = L"txtPreguntas";
			this->txtPreguntas->Size = System::Drawing::Size(422, 25);
			this->txtPreguntas->TabIndex = 1;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::SystemColors::ControlDarkDark;
			this->button1->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button1->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->button1->Location = System::Drawing::Point(169, 168);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(103, 29);
			this->button1->TabIndex = 2;
			this->button1->Text = L"Poco";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->BackColor = System::Drawing::SystemColors::ControlDarkDark;
			this->button2->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button2->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->button2->Location = System::Drawing::Point(278, 168);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(103, 29);
			this->button2->TabIndex = 3;
			this->button2->Text = L"Medio";
			this->button2->UseVisualStyleBackColor = false;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// button3
			// 
			this->button3->BackColor = System::Drawing::SystemColors::ControlDarkDark;
			this->button3->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button3->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->button3->Location = System::Drawing::Point(387, 168);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(113, 29);
			this->button3->TabIndex = 4;
			this->button3->Text = L"Mucho";
			this->button3->UseVisualStyleBackColor = false;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->BackColor = System::Drawing::Color::DimGray;
			this->button4->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button4->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->button4->Location = System::Drawing::Point(78, 168);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(73, 29);
			this->button4->TabIndex = 5;
			this->button4->Text = L"No";
			this->button4->UseVisualStyleBackColor = false;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// button5
			// 
			this->button5->BackColor = System::Drawing::Color::DimGray;
			this->button5->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button5->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->button5->Location = System::Drawing::Point(425, 203);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 63);
			this->button5->TabIndex = 6;
			this->button5->Text = L"Finalizar test";
			this->button5->UseVisualStyleBackColor = false;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// button6
			// 
			this->button6->BackColor = System::Drawing::Color::DimGray;
			this->button6->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->button6->ForeColor = System::Drawing::SystemColors::ButtonFace;
			this->button6->Location = System::Drawing::Point(78, 88);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(128, 37);
			this->button6->TabIndex = 7;
			this->button6->Text = L"Comenzar test";
			this->button6->UseVisualStyleBackColor = false;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->BackColor = System::Drawing::Color::Transparent;
			this->label1->Font = (gcnew System::Drawing::Font(L"Arial", 25, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->ForeColor = System::Drawing::SystemColors::ControlDarkDark;
			this->label1->Location = System::Drawing::Point(22, 26);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(78, 39);
			this->label1->TabIndex = 8;
			this->label1->Text = L"Test";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->BackColor = System::Drawing::Color::Transparent;
			this->label2->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::SystemColors::ControlDarkDark;
			this->label2->Location = System::Drawing::Point(25, 66);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(217, 19);
			this->label2->TabIndex = 9;
			this->label2->Text = L"Cuentanos como te sientes";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(655, 457);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtPreguntas);
			this->Controls->Add(this->Grilla);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grilla))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				
		   
			 if(i<preguntas.Get_tamano()){
			 string elemento;
			 preguntas.Mostrar(elemento,i,0);
			 txtPreguntas->Text=marshal_as<System::String^>(elemento);i++;
			 ingresarpuntos(1,0,0);
			 mostrarpuntos();
			 }

			 }


private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 if(i<preguntas.Get_tamano()){
			 string elemento;
			 preguntas.Mostrar(elemento,i,0);
			 txtPreguntas->Text=marshal_as<System::String^>(elemento);i++;
			 ingresarpuntos(0,0,0);
			 mostrarpuntos();
			 }
		 } 
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 if(i<preguntas.Get_tamano()){
			 string elemento;
			 preguntas.Mostrar(elemento,i,0);
			 txtPreguntas->Text=marshal_as<System::String^>(elemento);i++;
			 ingresarpuntos(0,1,0);
			 mostrarpuntos();

			 }
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 if(i<preguntas.Get_tamano()){
			 string elemento;
			 preguntas.Mostrar(elemento,i,0);
			 txtPreguntas->Text=marshal_as<System::String^>(elemento);i++;
			 ingresarpuntos(0,0,1);
			 mostrarpuntos();
			 }
		 }

		 
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(std>0){ Grilla->ColumnCount=3;
			  Grilla->RowCount=enfermedades.Get_tamano();
			  int vec1[]={0,1,0,1,0,1,0,1};//covid
			  porcentaje.Insertar(calcular(vec1),0,0);
			  int vec2[]={0,2,1,1,2,2,0,1};//tos
			  porcentaje.Insertar(calcular(vec2),1,0);
			  int vec3[]={0,2,0,1,0,2,1,1};//asma
			  porcentaje.Insertar(calcular(vec3),2,0);
			  int vec4[]={0,2,0,1,0,0,0,2};//artritis
			  porcentaje.Insertar(calcular(vec4),3,0);
			  int vec5[]={0,2,0,1,1,1,0,2};//cancer
			  porcentaje.Insertar(calcular(vec5),4,0);
			  int vec6[]={0,2,0,1,0,1,2,1};//vih
			  porcentaje.Insertar(calcular(vec6),5,0);
			  mostrarenfermedades();}
			 
		 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(n==0){inicio();
			 if(i<preguntas.Get_tamano()){
			 string elemento;
			 preguntas.Mostrar(elemento,i,0);
			 txtPreguntas->Text=marshal_as<System::String^>(elemento);i++;
			 }}n=1; std=1;
		 }

		 float calcular(int pos[])
		 {	 float suma=0;int elemento;
			 for(int fila=0;fila<puntos.Get_tamano()/3;fila++)
			 {
			 puntos.Mostrar(elemento,fila,pos[fila]);//fila columna
			 suma=suma+elemento;
			 }
			 return (suma/(puntos.Get_tamano()/3))*100;
		 }
		 void inicio()
			 {	 
				 //aqui van las preguntas
				 preguntas.Insertar("�Sentientes agotamiento, debilidad o fatiga?",0,0);
				 preguntas.Insertar("�Presentas fiebre?",1,0);//elemento fila columna
				 preguntas.Insertar("�Tienes dolor de cabeza?",2,0);
				 preguntas.Insertar("�Experimentas dificultad al respirar?",3,0);
				 preguntas.Insertar("�Te ha faltado el aliento?",4,0);
				 preguntas.Insertar("�Has tenido tos?",5,0);
				 preguntas.Insertar("�Sufres de dolor muscular?",6,0);
				 preguntas.Insertar("FIN",7,0);

				 enfermedades.Insertar("covid",0,0);
				 enfermedades.Insertar("Tos ferina",1,0);
				 enfermedades.Insertar("Asma",2,0);
				 enfermedades.Insertar("Artritis",3,0);
                 enfermedades.Insertar("Gripe",4,0);
				 enfermedades.Insertar("Refriado comun",5,0);
				 enfermedades.Insertar("Gastritis",6,0);
				 enfermedades.Insertar("Hemorragia",7,0);


			 }
		 void ingresarpuntos(int a, int b, int c)
		 {
			puntos.Insertar(a,lim,0);
			puntos.Insertar(b,lim,1);
			puntos.Insertar(c,lim,2);
			lim++;
		 }
		 void mostrarpuntos()
		 {	 int elemento;
			 Grilla->ColumnCount=3;
			 Grilla->RowCount=puntos.Get_tamano()/3;
			 for(int fila=0;fila<puntos.Get_tamano()/3;fila++)
			 {
				 for(int columna=0;columna<3;columna++)
				 {
					 puntos.Mostrar(elemento,fila,columna);
					 Grilla->Rows[fila]->Cells[columna]->Value=System::Convert::ToString(elemento);
				 }
			 }
		 }

		 void mostrarenfermedades()
		 {	 string elemento;
			 float elemento1;
			 for(int fila=0;fila<enfermedades.Get_tamano();fila++)
			 {	
				enfermedades.Mostrar(elemento, fila, 0);
				Grilla->Rows[fila]->Cells[0]->Value=marshal_as<System::String^>(elemento);
			 }

			 for(int fila=0;fila<enfermedades.Get_tamano();fila++)
			 {	
				porcentaje.Mostrar(elemento1, fila, 0);
				Grilla->Rows[fila]->Cells[1]->Value=System::Convert::ToString(elemento1);
			 }
			 
			 for(int fila=0;fila<enfermedades.Get_tamano();fila++)
			 {	
				porcentaje.Mostrar(elemento1, fila, 0);
				if(elemento1>90){Grilla->Rows[fila]->Cells[2]->Value=marshal_as<System::String^>("Muy probable");}
				if(elemento1>50&&elemento1<=90){Grilla->Rows[fila]->Cells[2]->Value=marshal_as<System::String^>("Poco probable");}
				if(elemento1>=0&&elemento1<=50){Grilla->Rows[fila]->Cells[2]->Value=marshal_as<System::String^>("Nada probable");}
				
			 }


		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
};

}

