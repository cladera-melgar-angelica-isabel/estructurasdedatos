#pragma once
//#include "Form1.h"

namespace Proyecto02 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Form2
	/// </summary>

	public ref class Form2 : public System::Windows::Forms::Form
	{
	public:
		Form2(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btntest;
	protected: 

	protected: 

	protected: 

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form2::typeid));
			this->btntest = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// btntest
			// 
			this->btntest->BackColor = System::Drawing::SystemColors::ControlDarkDark;
			this->btntest->Font = (gcnew System::Drawing::Font(L"Arial", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btntest->ForeColor = System::Drawing::SystemColors::ButtonHighlight;
			this->btntest->Location = System::Drawing::Point(123, 139);
			this->btntest->Name = L"btntest";
			this->btntest->Size = System::Drawing::Size(167, 36);
			this->btntest->TabIndex = 0;
			this->btntest->Text = L"Ir al test";
			this->btntest->UseVisualStyleBackColor = false;
			this->btntest->Click += gcnew System::EventHandler(this, &Form2::btntest_Click);
			// 
			// Form2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackgroundImage = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"$this.BackgroundImage")));
			this->ClientSize = System::Drawing::Size(716, 407);
			this->Controls->Add(this->btntest);
			this->Name = L"Form2";
			this->Text = L"Form2";
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			

			 }
	private: System::Void btntest_Click(System::Object^  sender, System::EventArgs^  e) {
				/* Form1 ^Test=gcnew Form1();
			 Test->ShowDialog();
			 */
			 }
	};
}
