#include "StdAfx.h"
#include "Form2.h"

/*using namespace Proyecto02;
int main()
{Application::EnableVisualStyles();
 Application::Run(gcnew Form2());
return 0;
}*/