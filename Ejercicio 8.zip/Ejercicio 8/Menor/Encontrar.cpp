#include "StdAfx.h"
#include "Encontrar.h"
#define T 20


Encontrar::Encontrar(void)
{
	vec[T]=0;
	tamano=0;
}
int Encontrar::Get_tamano()
{
	return tamano;
}
void Encontrar::Set_tamano(int tam)
{
	tamano=tam;
}
double Encontrar::Get_vector(int posicion)
{
	return vec[posicion];
}
void Encontrar::Set_vector(int posicion, double elemento)
{
	vec[posicion]=elemento;
}
bool Encontrar::LlenoVector()
{
	if(tamano==T-1)
	{return true;}
	else{return false;}
}
bool Encontrar::VacioVector()
{
	if(tamano==0)
	{return true;}
	else{return false;}
}
bool Encontrar::Llenar(int posicion, double elemento)
{
	if((posicion<0)&&(posicion>tamano))
	{return false;}
		else
			{if(LlenoVector()==true)
				{return false;}
				else
				{int i=Get_tamano();
					while(i>posicion)
					{
						vec[i]=vec[i-1];
						i--;
					}
					vec[i]=elemento;
					return true;
				}
			}
}
double Encontrar::BuscarDiferencia(int tam)
{
	double Diferencia=vec[0]-vec[1];
	for(int i=1;i<tam;i++)
	{
		if((vec[i]-vec[i+1])>Diferencia)
		{
			Diferencia=vec[i]-vec[i+1];
		}
	}
	return Diferencia;
}
