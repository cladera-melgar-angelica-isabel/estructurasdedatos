#include "StdAfx.h"
#include "parcial_parte1.h"//Esta libreria al crear la clase ya esta, pero en caso que no este es muy importante colocarla


parcial_parte1::parcial_parte1(void)//constructor
{num=0;//Puse que el valor por defecto del numero ingresado debe ser 0
}
int parcial_parte1::Get_num()
{return num;//retorna un entero
}
	void parcial_parte1::Set_num(int n)
	{num=n;//se le esta asignando el valor a num
	}
	int parcial_parte1::factorial()//no se le envio ningun parametro porque ya estan definidos en la clase, en la parte de .h
	{
		int f;//se define un variable para almacenar el factorrial del numero
		int s=0;//esta variable va almacenar la suma de los factoriales. Su valor inicial es cero, para evitar que este con basura
			int d;// la esta varible va aagrar cada digito por separado
		while(num>0)//mientras que num se mayor a 0 se hara este proceso
		{f=1;//Al ser un proceso repetitivo, la vriable f va a empezar siempre con el valor 1, por ser el valor neutro el la multiplicacion.
		d=num%10;//d es igual al residuo de dividir num entre 10 
		for(int i=1;i<=d;i++)// este proceso es para sacar el factorial de cada digito
		{//se le pone i=1, por ser el elemento neutro de la multiplicacion.
		//puse que i<=d porque el factorial debe ser desde 1 hasta el digito. en caso de ser 0 el digito el factotrial de 0 es 1 asique este proceso lo incluye.
			f=f*i;
		}
		s=s+f;//se esta almacenando la suma
		num=num/10;//Aqui se esta disminuyendo el valor de num para que no siempre nos salga el calor del primer digito
		}
		return s;//retorna la suma total
	}

	//hay algunas cosas que no coloque cuando envie mi examen pero que son importantes para la ejecucion correcta del programa