#pragma once
#include <iostream>//librerias, entre ellas hay alguna muy importantes como hay algunas que no lo son mucho
#include <string>//Algunas libreria las puse por siacaso
#include <msclr\marshal_cppstd.h>

#include "parcial_parte1.h"

namespace PARCIAL111 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;


	parcial_parte1 objeto;//Cree un objeto global


	/// <summary>
	/// Resumen de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtnumero;
	private: System::Windows::Forms::Button^  btndeterminar;


	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtnumero = (gcnew System::Windows::Forms::TextBox());
			this->btndeterminar = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(48, 38);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(44, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Numero";
			// 
			// txtnumero
			// 
			this->txtnumero->Location = System::Drawing::Point(116, 38);
			this->txtnumero->Name = L"txtnumero";
			this->txtnumero->Size = System::Drawing::Size(100, 20);
			this->txtnumero->TabIndex = 1;
			// 
			// btndeterminar
			// 
			this->btndeterminar->Location = System::Drawing::Point(87, 104);
			this->btndeterminar->Name = L"btndeterminar";
			this->btndeterminar->Size = System::Drawing::Size(75, 23);
			this->btndeterminar->TabIndex = 2;
			this->btndeterminar->Text = L"Determinar";
			this->btndeterminar->UseVisualStyleBackColor = true;
			this->btndeterminar->Click += gcnew System::EventHandler(this, &Form1::btndeterminar_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btndeterminar);
			this->Controls->Add(this->txtnumero);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndeterminar_Click(System::Object^  sender, System::EventArgs^  e) {

				 
				 
				 int elem,numero;//Cree dos variables para que almacenen dos numeros 
				 //elem va almacenar el valor que se escribio al comienzo de programa
				 elem=System::Convert::ToInt32(txtnumero->Text);//al estar en la propiedad de Text en textbox se utiliza un metodo de conversion 
				 objeto.Set_num(elem);//Le esta eviando el valor del elem para que la clase lo tenga

				 numero=objeto.factorial();//almacena el valor de la suma total que sacamos
				 if(elem==numero)//Aqui se hace la pregunta que si numero que se ingreso es igual a la suma de los factoriales de cada uno de sus digitos
				 {
				  MessageBox::Show("ES UN NUMERO CURIOSO");//Si se cumple te va salir un mensaje que te lo confirma
				 
				 }
				 else
				 {
				  MessageBox::Show("NO ES UN NUMERO CURIOSO");//Caso contrario igual te manda un mensaje pero este te dice que no.
				 }





			 }
	};
}

