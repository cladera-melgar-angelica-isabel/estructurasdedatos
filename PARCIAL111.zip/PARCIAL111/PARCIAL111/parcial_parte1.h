#pragma once
//Ingeniera como no puede hablar durante la defensa del codigo voy a escrtibir por comentarios lo que hice

//Parte 1.Ejercicio 2. Determinar si un numero es curioso 

class parcial_parte1
{
private:
	int num;//Creamos atributos. En este caso solo cree uno porque no vi necesario colocar mas 
	
public:
	parcial_parte1(void);//Construcctor, este se crea al crear la clase

	int Get_num();//El Get para traer el valor de la clase al programa
	void Set_num(int n);//Para asignar el valor de programa a la clase


	
	int factorial();//Metodo que va hacer lo que el enunciado nos pide. 
	//El metodo se podia llamar de cualquier forma,en esta vez lo llame factorial, sin embargo no solo me saca el factorial. 



};

