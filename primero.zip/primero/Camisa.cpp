#include "StdAfx.h"
#include "Camisa.h"


Camisa::Camisa(void)
{
}
string Camisa::Get_tipodecuello()
{return tipodecuello;
}
string Camisa::Get_tipodemanga()
{return tipodemanga;
}
double Camisa::Get_talla()
{return talla;
}
void Camisa::Set_tipodecuello(string tdc)
{tipodecuello=tdc;
}
void Camisa::Set_tipodemanga(string tdm)
{tipodemanga=tdm;
}
void Camisa::Set_talla(double t)
{talla=t;
}
