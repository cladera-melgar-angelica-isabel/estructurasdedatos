#pragma once
#include <iostream>
#include <string>

using namespace std;

class Mercaderiatienda
{
protected:
	double saldounidades,saldovalorado,codigo;
	double preciounitario;

public:
	Mercaderiatienda(void);
	double Get_codigo();
	double Get_saldovalorado();
	double Get_saldounidades();
	double Get_preciounitario();
	
	void Set_codigo(double c);
	void Set_saldovalorado(double sv);
	void Set_saldounidades(double su);
	void Set_preciounitario(double pu);
	
	void ingreso(double cantidad);
	void egreso(double cantidad);



};


