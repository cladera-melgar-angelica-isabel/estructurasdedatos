#pragma once
#include "Mercaderiatienda.h"
#include <iostream>
#include <string>

using namespace std;
class Pantalones:Mercaderiatienda
{
private:
	string tipodecorte,tipodetiro;
	double talla;
public:
	Pantalones(void);
	string Get_tipodecorte();
	string Get_tipodetiro();
	double Get_talla();
	void Set_tipodecorte(string tdc);
	void Set_tipodetiro(string tdt);
	void Set_talla(double t);
};

