#include "StdAfx.h"
#include "Mercaderiatienda.h"


Mercaderiatienda::Mercaderiatienda(void)
{
}
double Mercaderiatienda::Get_codigo()
{return codigo;
}
double Mercaderiatienda::Get_saldovalorado()
{return saldovalorado;
}
double Mercaderiatienda::Get_saldounidades()
{return saldounidades;
}
double Mercaderiatienda::Get_preciounitario()
{return preciounitario;
}
	
void Mercaderiatienda::Set_codigo(double c)
{codigo=c;
}
void Mercaderiatienda::Set_saldovalorado(double sv)
{saldovalorado=sv;
}
void Mercaderiatienda::Set_saldounidades(double su)
{saldounidades=su;
}
void Mercaderiatienda::Set_preciounitario(double pu)
{preciounitario=pu;
}
	
void Mercaderiatienda::ingreso(double cantidad)
{if (cantidad<0)
{cout<<"Error. Valor no apto"<<endl;
 return;}
saldounidades=saldounidades+cantidad;
saldovalorado=saldovalorado+cantidad*preciounitario;
}
void Mercaderiatienda::egreso(double cantidad)
{if(saldounidades-cantidad<0)
{cout<<"Error. Valor no apto"<<endl;
 return;}
saldounidades=saldounidades-cantidad;
saldovalorado=saldovalorado-cantidad*preciounitario;
}
