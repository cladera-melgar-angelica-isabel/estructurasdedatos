#pragma once
#include "Mercaderiatienda.h"
#include <iostream>
#include <string>

using namespace std;

class Accesorios:Mercaderiatienda
{
protected:
	string material, color;

public:
	Accesorios(void);
	string Get_material();
	string Get_color();
	void Set_material(string m);
	void Set_color(string c);
};

