#pragma once
#include "Mercaderiatienda.h"
#include <iostream>
#include <string>

using namespace std;
class Camisa:public Mercaderiatienda
{
private:
	string tipodecuello,tipodemanga;
	double talla;
public:
	Camisa(void);
	string Get_tipodecuello();
	string Get_tipodemanga();
	double Get_talla();
	void Set_tipodecuello(string tdc);
	void Set_tipodemanga(string tdm);
	void Set_talla(double t);
	
};

