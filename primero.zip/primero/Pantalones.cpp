#include "StdAfx.h"
#include "Pantalones.h"


Pantalones::Pantalones(void)
{
}
string Pantalones::Get_tipodecorte()
{return tipodecorte;
}
string Pantalones::Get_tipodetiro()
{return tipodetiro;
}
double Pantalones::Get_talla()
{return talla;
}
void Pantalones::Set_tipodecorte(string tdc)
{tipodecorte=tdc;
}
void Pantalones::Set_tipodetiro(string tdt)
{tipodetiro=tdt;
}
void Pantalones::Set_talla(double t)
{talla=t;
}
