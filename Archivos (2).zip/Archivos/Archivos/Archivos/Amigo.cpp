#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

//MANEJA EL REGISTRO

class Amigo {
private:
	string 	nombre;
	int		edad;
	char	sexo;
	char	estado;		//eliminado = E, activo = A

public:
	Amigo() {//constructor
		nombre = "";
		edad		= 0;
		sexo		= ' ';
		estado		= ' ';
	}
	//Set a todo el registro
	Amigo(string nom, int ed, char sx) {
		nombre	= nom;
		edad	= ed;
		sexo	= sx;
		estado  = 'A';
	}
	//borado fisico o logico, logico lo haces con un estado, 
	void setAmigo(string nom, int ed, char sx) {
		nombre		= nom;
		edad		= ed;
		sexo		= sx;
		estado		= 'A';
	}

	string getNombre() {
		return(nombre);
	}

	int getEdad() {
		return(edad);
	}

	char getSexo() {
		return(sexo);
	}

	char getEstado() {
		return(estado);
	}

	void guardarArchivo(ofstream &fsalida) {
		fsalida.write(reinterpret_cast<char *>(&nombre), sizeof(nombre));//sizeof??
		fsalida.write(reinterpret_cast<char *>(&edad), sizeof(edad));
		fsalida.write(reinterpret_cast<char *>(&sexo), sizeof(sexo));
		fsalida.write(reinterpret_cast<char *>(&estado), sizeof(estado));
	}

	bool leerArchivo(ifstream &fentrada) {
		bool k = false;//no hizo una revision del estado.
		if (fentrada.is_open() == true) {//si existe y esta
			fentrada.read(reinterpret_cast<char *>(&nombre), sizeof(nombre));
			if (fentrada.eof() == false) {				
				fentrada.read(reinterpret_cast<char *>(&edad), sizeof(edad));
				fentrada.read(reinterpret_cast<char *>(&sexo), sizeof(sexo));
				fentrada.read(reinterpret_cast<char *>(&estado), sizeof(estado));
				k = true;
			}else {
				//cout << endl << "Registro no existe";
			}
		}else {
			cout << endl << "Arhivo no existe";
		}
		return(k);//para decir que sigue leyendo, lee todo el archivo
	}

	bool eliminar(fstream &fes, int nroReg){
		bool k = false;
		if (fes.is_open() == true) {// si existe, si se pudo abrir
			fes.seekg(getTamBytesRegistro() * (nroReg - 1), ios::beg);
			fes.read(reinterpret_cast<char *>(&nombre), sizeof(nombre));//solo lee nombre
			if (fes.eof() == false) {
				fes.read(reinterpret_cast<char *>(&edad), sizeof(edad));
				fes.read(reinterpret_cast<char *>(&sexo), sizeof(sexo));
				fes.read(reinterpret_cast<char *>(&estado), sizeof(estado));
		
				estado = 'E';
				fes.seekp(getTamBytesRegistro() * (nroReg - 1), ios::beg);//se vuelve a posicionar
				fes.write(reinterpret_cast<char *>(&nombre), sizeof(nombre));
				fes.write(reinterpret_cast<char *>(&edad), sizeof(edad));
				fes.write(reinterpret_cast<char *>(&sexo), sizeof(sexo));
				fes.write(reinterpret_cast<char *>(&estado), sizeof(estado));//aqui se modifica
				k = true;//cuando ya esta en un estado E es como si ya no existiera 
			}else {
				cout << endl << "Registro no existe";
			}			
		}else {
			cout << endl << "Arhivo no existe";
		}
		return(k);
	}


	bool modificar(fstream &fes, int nroReg){
		bool k = false;
		if (fes.is_open() == true) {
			string nomAux;
			nomAux=nombre;
			fes.seekg(getTamBytesRegistro() * (nroReg - 1), ios::beg);//Calcula la direccion fisica en base a la logica
			//Funciones jask??
			fes.read(reinterpret_cast<char *>(&nombre), sizeof(nombre));
			if (fes.eof() == false) {
				nombre=nomAux;
				estado = 'A';//lo vuelvo habilitar
				fes.seekp(getTamBytesRegistro() * (nroReg - 1), ios::beg);
				fes.write(reinterpret_cast<char *>(&nombre), sizeof(nombre));
				fes.write(reinterpret_cast<char *>(&edad), sizeof(edad));
				fes.write(reinterpret_cast<char *>(&sexo), sizeof(sexo));
				fes.write(reinterpret_cast<char *>(&estado), sizeof(estado));
				k = true;
			}else {
				cout << endl << "Registro no existe";
			}			
		}else {
			cout << endl << "Arhivo no existe";
		}
		return(k);
	}

	bool buscar(ifstream &fentrada, int nroReg) {//cuando consultas un dato del registro,solo lee
		//NO MODIFICA SOLO LEE.
		bool k = false;
		if (fentrada.is_open() == true) {
			fentrada.seekg(getTamBytesRegistro() * (nroReg - 1), ios::beg);
			fentrada.read(reinterpret_cast<char *>(&nombre), sizeof(nombre));
			fentrada.read(reinterpret_cast<char *>(&edad), sizeof(edad));
			fentrada.read(reinterpret_cast<char *>(&sexo), sizeof(sexo));
			fentrada.read(reinterpret_cast<char *>(&estado), sizeof(estado));
			if (fentrada.eof() == false) {
				k = true;
			}
			else {
				//cout << endl << "Registro no XX existe";
			}
		}
		else {
			cout << endl << "Arhivo no existe";
		}
		return(k);
	}

	int getTamBytesRegistro() {
		return(sizeof(nombre) + sizeof(edad) + sizeof(sexo) + sizeof(estado) );
	}

};
