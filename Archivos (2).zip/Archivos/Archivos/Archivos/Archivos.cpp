// Archivos.cpp : main project file.

#include "stdafx.h"

#include "StdAfx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.cpp"

using namespace std;


void main() {
	ABMamigo *amig = new ABMamigo("amigOO.dat");
	//amig00.dat -> ES UN ARCHIVO DENTRO DE MI DIRECTORIO
	int op;
	/*amig->adicionarNuevo();
	amig->listar();
	amig->buscarReg();
	amig->eliminarReg();
	amig->modificarReg();
	amig->listar();*/
	do{
		cout<<"\n\t1. Adicionar Nuevo  ";
		cout<<"\n\t2. Mostrar Registro  ";
		cout<<"\n\t3. Burcar Registro ";
		cout<<"\n\t4. Modificar Registro  ";
		cout<<"\n\t5. Eliminar Registro";
		cout<<"\n\t6. Finalizar";
		cout<<"\n\tOpcion:  ";cin>>op;

		switch(op)
		{case 1: amig->adicionarNuevo();
		 break;
		 case 2: amig->listar();
		 break;
		 case 3: amig->buscarReg();
		 break;
		 case 4: amig->modificarReg();
		 break;
		 case 5: amig->eliminarReg();
		 break;
		}
	}while(op!=6);

	getch();
	 
}

