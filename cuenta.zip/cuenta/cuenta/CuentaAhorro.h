#pragma once
#include <iostream>
#include <string>
#include "Cuentab.h"

using namespace std;

class CuentaAhorro:public Cuentab
{
private:
	double cuotaman;
public:
	CuentaAhorro();
	double Get_cuotaman();
	void Set_cuotaman(double cantidad);
	void reintegro(double cantidad);
};

