#include "StdAfx.h"
#include "Cuentab.h"



Cuentab::Cuentab(void)
{
}
double Cuentab::Get_saldo()
{return saldo;
}
double Cuentab::Get_interes()
{return interes;
}
string Cuentab::Get_cuenta()
{return cuenta;
}
string Cuentab::Get_nombre()
{return nombre;
}
void Cuentab::Set_saldo(double s)
{saldo=s;
}
void Cuentab::Set_interes(double i)
{interes=i;
}
void Cuentab::Set_cuenta(string c)
{cuenta=c;
}
void Cuentab::Set_nombre(string n)
{nombre=n;
}
void Cuentab::ingreso(double cantidad)
{if (cantidad<0)
{cout<<"Error. Cantidad negativa"<<endl;
 return;
}
saldo=saldo+cantidad;
}
void Cuentab::reintegro(double cantidad)
{if (saldo-cantidad<0)
{cout<<"Error. No dispone de suficiente saldo"<<endl;
 return;
}
saldo=saldo-cantidad;
}

double Cuentab::estado()
{return saldo;
}
