#include "StdAfx.h"
#include "CuentaAhorro.h"


CuentaAhorro::CuentaAhorro(void)
{
}
double CuentaAhorro::Get_cuotaman()
{return cuotaman;
}
void CuentaAhorro::Set_cuotaman(double cantidad)
{cuotaman=cantidad;
}
void CuentaAhorro::reintegro(double cantidad)
{saldo=saldo+cantidad;
}