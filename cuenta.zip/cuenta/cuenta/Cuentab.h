#pragma once
#include <iostream>
#include <string>

using namespace std;

class Cuentab
{
protected:
	double saldo,interes;
	string cuenta;
	string nombre;
	void haceralgo(void);
public:
	Cuentab(void);
	double Get_saldo();
	double Get_interes();
	string Get_cuenta();
	string Get_nombre();
	void Set_saldo(double s);
	void Set_interes(double i);
	void Set_cuenta(string c);
	void Set_nombre(string n);
	void ingreso(double cantidad);
	void reintegro(double cantidad);
	
	double estado();
};

