//PARTE 2. EJERCICIO 3. SACAR LA MEJORES TRAS NOTAS DE UN GRUPO DE ALUMNOS
//Ingeniera como no pude explicar mi codigo en horas de clase voy a poner comentarios
//El programa no hace en su totalidad lo que el problema pide, y en el video usted se va a dar cuenta cuales fueron mis errores
//Corregi algunas cosasque habia hecho mal durante el video.
#pragma once
#include <string>//estas librerias las puse porque al utilizar string eran necesarias
#include <iostream>

using namespace std;

class Parcial_1_2
{
private:
	int nota[20];//La nota la puse como entero por que asi lo empece en el video.
	//Se podria cambiar a bouble, claro que se tendria que cambiar todo, como la clase de parametros que mandan y en el Form1.h el metodo de convertir
	
	int tamano;//Este si es entero porque no hay un tamano 1.4, en realidad deberia ser solo numeros naturales poruqe igual no hay posicion -1.
	//para eso se deberia validar el numero de ingreso.
	
	
	//string nombre[20]; 
	//Todo lo que tenga que ver con el nombre lo voy a poner como comentario.
	//Esto lo hice para ver si la parte numerica funciona.




public:
	Parcial_1_2(void);//constructor
	virtual ~Parcial_1_2(void);//destructor, aunque en este programa no es necesario

	int Get_tamano();//El Get para traer el valor de la clase al programa
	void Set_tamano(int t);//Para asignar el valor de programa a la clase

	int Get_nota(int p);//Pasa lo mismo que con tamano, pero al ser vector se debe enviar la posicion
	void Set_nota(int p,int elem);//En esta ocacion se debe enviar la posicion y el elemnto 
	
	//string Get_nombre(int p);
	//void Set_nombre(int p,string nom);


	bool ingresar(int p,int elem);//este metodo es para el igreso de las notas
	//este metodo cambio a como estaba en el video
	//bool ingresarnom(int p,string nom);



	void ordenar(); //en el enunciado nos recomienta ordenar el vector.
	



};

