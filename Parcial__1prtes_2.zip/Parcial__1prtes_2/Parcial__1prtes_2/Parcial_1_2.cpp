#include "StdAfx.h"
#include "Parcial_1_2.h"//Libreria muy importante que no debe faltar
#include <string>//estas librerias las puse por que pense que iba a usar string
#include <iostream>

using namespace std;

Parcial_1_2::Parcial_1_2(void)
{nota[20]=0;//al comenzar todos los valores del vector va a ser 0
tamano=0;//el valor por defecto del tamano es 0
//nombre[20]="0";
}


Parcial_1_2::~Parcial_1_2(void)
{
}

int Parcial_1_2::Get_tamano()
{return tamano;//retorna el valor numerico de tamano
}
	void Parcial_1_2::Set_tamano(int t)
	{tamano=t;//se le asigna un valor a tamano
	}
	int Parcial_1_2::Get_nota(int p)
	{return nota[p];//va aretornar el vector nota en la posicion p
	}
	void Parcial_1_2::Set_nota(int p,int elem)
	{nota[p]=elem;//en vector nota posicion p es igual al numero elem
	}
	
	/*string Parcial_1_2::Get_nombre(int p)
	{return nombre[p];
	}
	void Parcial_1_2::Set_nombre(int p,string nom)
	{nombre[p]=nom;
	}
	*/

	bool Parcial_1_2::ingresar(int p,int elem)//Al ser booleano tiene que retorna True o False
	{
		if((p<0)||(p>tamano))//Pregunta si la posicion es menor a 0 o mayor al tamano
		{return false;//si se cumple retorna falso
		}
		else//caso contrario
		{nota[p]=elem;//la nota en esa posicion va a ser igual el elemento enviado
		return true;//retorna verdadero
		
		}
	}

	/*bool Parcial_1_2::ingresarnom(int p,string nom)
	{
		if((p<0)||(p>tamano))
		{return false;
		}
		else
		{nombre[p]=nom;
		return true;
		
		}
	}
*/

	void Parcial_1_2::ordenar()
	{
		int auxnot;//es un auxiliar que va almacenar el valor para que no se pierda
		//string auxnom;
		for(int i=0;i<tamano-1;i++)//utilice el metodo burbuja
		{
			for(int k=1+i;k<tamano;k++)//Se utilizan dos for 
			{if(nota[k]>nota[i])//Aqui se hace la pregunta para saber cual es mayor, si nota[i] es mayor se mantiene 
			{//caso contrario se hace este proceso
				auxnot=nota[i];//el auxiliar almacena el valor del menor
				nota[i]=nota[k];//cambian de lugar para que este de mayor a menor
				nota[k]=auxnot;//el valor que antes tenia nota[i] y se lo asignan a nota[k]


				/*auxnom=nota[i];
				nombre[i]=nombre[k];
				nombre[k]=auxnom*/;
			}

			}
		}
	}