#include "StdAfx.h"
#include "operaciones.h"


operaciones::operaciones(void)
{
	pila();
}
void operaciones::Guardar(DataGridView^  grilla_pila){
	int i=0;
	Nodo ele;
	while(i<grilla_pila->RowCount-1){
	ele.Set_nombre(marshal_as<std::string>(System::Convert::ToString(grilla_pila->Rows[i]->Cells[0]->Value)));
	ele.Set_numero(System::Convert::ToInt32(grilla_pila->Rows[i]->Cells[1]->Value));
	pila::Insertar(ele);
	i++;
	}
}
void operaciones::Mostrar(DataGridView^  grilla_pila){
	grilla_pila->ColumnCount=2;
	grilla_pila->RowCount=pila::Get_tope()+1;
	Nodo ele;
	pila aux;
	int i=0;
	while(pila::Pila_vacia()==false){
	pila::Eliminar(ele);
	aux.Insertar(ele);
	
	}
	while(aux.Pila_vacia()==false){
	
	aux.Eliminar(ele);

	grilla_pila->Rows[i]->Cells[0]->Value=marshal_as<System::String^>(ele.Get_nombre());
	grilla_pila->Rows[i]->Cells[1]->Value=System::Convert::ToString(ele.Get_numero());i++;
	pila::Insertar(ele);
	}

}
void operaciones::Invertir()
{
pila aux;
Nodo ele;
while(pila::Pila_vacia()==false)
{
	pila::Eliminar(ele);
	aux.Insertar(ele);
}
pila::This_pila(aux);
}
void operaciones::Eliminaruno(int val){
	pila aux;
	Nodo ele;
	int n=0;
	while(pila::Pila_vacia()==false)
	{
	pila::Eliminar(ele);
	if(ele.Get_numero()==val&&n==0){n=1;}
	else{aux.Insertar(ele);}
	}
	pila::This_pila(aux);
	Invertir();
}
void operaciones::Repetidos()
{	pila aux,aux2,aux1;
	aux=pila::This_pila();
	Nodo ele1,ele2,ele3;
	int val1,val2;
	while(aux.Pila_vacia()==false)
	{
        aux.Eliminar(ele1);
		val1=ele1.Get_numero();
	    while(aux.Pila_vacia()==false)
	    {
	       aux.Eliminar(ele2);
		   val2=ele2.Get_numero();
	       if(val1!=val2)    { aux1.Insertar(ele2);}                 
	    }
		while(aux1.Pila_vacia()==false)
		{
			aux1.Eliminar(ele3);
			aux.Insertar(ele3);
		}
		aux2.Insertar(ele1);
	}
	pila::This_pila(aux2);
}
void operaciones::Ordenar()
{
	
	pila aux, nuevo, real;
	nuevo=pila::This_pila();
	Nodo ele,ele1;
	int val, val1;
	int mayor;
	
	while(pila::Pila_vacia()==false)
	{
	pila::Eliminar(ele);
	pila::Insertar(ele);
	mayor=ele.Get_numero();
	aux=pila::This_pila();

		while(aux.Pila_vacia()==false)
		{
			aux.Eliminar(ele1);
			val1=ele1.Get_numero();
			if(mayor<val1){  mayor=val1;ele=ele1; }
		} Eliminaruno(mayor);

	real.Insertar(ele);

	}
	pila::This_pila(real);

}
void operaciones::Primos(int limite){
	pila aux;
	Nodo ele, ele1;
	
	int j=1, divisor=0,cantidad=0,suma=0;
	
	while(cantidad!=limite){
		j++;
		divisor=0;

		for(int i=2;i<=j;i++){
			if(j%i==0){divisor++;}
		}
		
		if(divisor==1)
		{// j es primo
			suma=suma+j;
			ele.Set_numero(j);
			aux.Insertar(ele);
			cantidad++;
			
		}

	    }
	
	pila::This_pila(aux);
	Invertir();
	ele1.Set_numero(suma);
	pila::Insertar(ele1);
	Invertir();
}

void operaciones::Insertaruno(int posicion, Nodo elemento)
{	Nodo ele;int k=-1;
	posicion=posicion-1;
	int limite=posicion;
	
	pila aux;
	Invertir();
	while(pila::Pila_vacia()==false){
		k++;
		pila::Eliminar(ele);
		if(k==limite){aux.Insertar(elemento);}
		aux.Insertar(ele);
	}
	pila::This_pila(aux);
	
}

/*	pila aux, nuevo, real;
	nuevo=pila::This_pila();
	Nodo ele,ele1;
	int val, val1;
	int mayor;
	while(pila::Pila_vacia()==false)
	{
	pila::Eliminar(ele);
	mayor=ele.Get_numero();
	aux=pila::This_pila();
		while(aux.Pila_vacia()==false)
		{
			aux.Eliminar(ele1);
			val1=ele1.Get_numero();
			if(mayor<val1){  mayor=val1;ele=ele1; }
		} Eliminaruno(mayor);

	real.Insertar(ele);

	}
	pila::This_pila(real);*/

/*pila aux, borrar, real;
	Nodo ele, ele1;
	int val;
	borrar=pila::This_pila();
	borrar.Eliminar(ele);

	int mayor=ele.Get_numero();

	while(pila::Pila_vacia()==false){
	aux=pila::This_pila();
	while(aux.Pila_vacia()==false)
	{
		aux.Eliminar(ele1);
		val=ele1.Get_numero();
		if(mayor<val){mayor=val;ele=ele1;}

	}
	Eliminaruno(mayor);
	real.Insertar(ele);
	}

	pila::This_pila(real);*/
	
