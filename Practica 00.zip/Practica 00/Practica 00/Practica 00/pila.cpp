#include "StdAfx.h"
#include "pila.h"


pila::pila(void)
{
	tope=-1;
}
bool pila::Insertar(Nodo val)
{	if(Pila_llena()==true){return false;}
	else{
		tope++;
		pil[tope]=val;
	}

}

bool pila::Eliminar(Nodo &val)
{	if(Pila_vacia()==true){return false;}
	else{
		
		val=pil[tope];
		tope--;
	}

}

bool pila::Pila_vacia(){
	if(tope==-1){return true;}
	else{return false;}
}
bool pila::Pila_llena(){
	if(tope==t){return true;}
	else{return false;}
}
int pila::Get_tope(){
	return tope+1;
}

