#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "Nodo.h"
using namespace std;
using namespace msclr::interop;
#define t 10

 class pila: public	Nodo
{
	Nodo pil[10];
	int tope;
public:
	pila(void);
	bool Insertar(Nodo val);
	bool Eliminar(Nodo &val);
	bool Pila_vacia();
	bool Pila_llena();
	int Get_tope();
	pila This_pila(){return *this;}
	void This_pila(pila x){*this=x;}
};

