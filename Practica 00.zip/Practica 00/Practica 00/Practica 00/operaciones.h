#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "pila.h"
using namespace std;
using namespace msclr::interop;
	using namespace System::Windows::Forms;
class operaciones: public pila
{
public:
	operaciones(void);
	void Guardar(DataGridView^  grilla_pila);
	void Mostrar(DataGridView^  grilla_pila);
	void Invertir();
	void Eliminaruno(int val);
	void Repetidos();
	void Ordenar();
	void Primos(int limite);
	void Insertaruno(int posicion, Nodo elemento);


};

