#pragma once//Tiene los datos
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
using namespace std;
using namespace msclr::interop;
 class Nodo
{

	
	string nombre;
	int numero;

public:
	Nodo(void){
	numero=0;
	nombre=' ';}
	int Get_numero(){return numero;}
	void Set_numero(int num){numero=num;}

	string Get_nombre(){return nombre;}
	void Set_nombre(string nom){nombre=nom;}
};

