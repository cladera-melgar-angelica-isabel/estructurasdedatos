#pragma once
#include <iostream>
#include <string>
#include <msclr\marshal_cppstd.h>
#include "operaciones.h"
using namespace std;
using namespace msclr::interop;

namespace Practica00 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de Form1
	/// </summary>
	operaciones pilas;
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  grilla1;
	protected: 
	private: System::Windows::Forms::DataGridView^  grilla2;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  btnEliminaruno;
	private: System::Windows::Forms::TextBox^  txtUno;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::TextBox^  txtPosicion;

	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::TextBox^  txtElemento;

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtNumero;

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->grilla1 = (gcnew System::Windows::Forms::DataGridView());
			this->grilla2 = (gcnew System::Windows::Forms::DataGridView());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->btnEliminaruno = (gcnew System::Windows::Forms::Button());
			this->txtUno = (gcnew System::Windows::Forms::TextBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->txtPosicion = (gcnew System::Windows::Forms::TextBox());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->txtElemento = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->BeginInit();
			this->SuspendLayout();
			// 
			// grilla1
			// 
			this->grilla1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla1->Location = System::Drawing::Point(49, 71);
			this->grilla1->Name = L"grilla1";
			this->grilla1->Size = System::Drawing::Size(298, 217);
			this->grilla1->TabIndex = 0;
			// 
			// grilla2
			// 
			this->grilla2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla2->Location = System::Drawing::Point(496, 71);
			this->grilla2->Name = L"grilla2";
			this->grilla2->Size = System::Drawing::Size(310, 217);
			this->grilla2->TabIndex = 1;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(272, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 53);
			this->button1->TabIndex = 2;
			this->button1->Text = L"Tamano";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(496, 12);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 53);
			this->button2->TabIndex = 3;
			this->button2->Text = L"Mostrar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(49, 29);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(111, 20);
			this->txtTamano->TabIndex = 4;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(385, 12);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 53);
			this->button3->TabIndex = 5;
			this->button3->Text = L"Ingresar";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// btnEliminaruno
			// 
			this->btnEliminaruno->Location = System::Drawing::Point(385, 146);
			this->btnEliminaruno->Name = L"btnEliminaruno";
			this->btnEliminaruno->Size = System::Drawing::Size(75, 41);
			this->btnEliminaruno->TabIndex = 6;
			this->btnEliminaruno->Text = L"Eliminar uno";
			this->btnEliminaruno->UseVisualStyleBackColor = true;
			this->btnEliminaruno->Click += gcnew System::EventHandler(this, &Form1::btnEliminaruno_Click);
			// 
			// txtUno
			// 
			this->txtUno->Location = System::Drawing::Point(375, 120);
			this->txtUno->Name = L"txtUno";
			this->txtUno->Size = System::Drawing::Size(100, 20);
			this->txtUno->TabIndex = 7;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(385, 235);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(75, 53);
			this->button4->TabIndex = 8;
			this->button4->Text = L"Invertir";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// txtPosicion
			// 
			this->txtPosicion->Location = System::Drawing::Point(66, 326);
			this->txtPosicion->Name = L"txtPosicion";
			this->txtPosicion->Size = System::Drawing::Size(100, 20);
			this->txtPosicion->TabIndex = 10;
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(189, 351);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(75, 41);
			this->button5->TabIndex = 9;
			this->button5->Text = L"Insertar";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// txtElemento
			// 
			this->txtElemento->Location = System::Drawing::Point(66, 362);
			this->txtElemento->Name = L"txtElemento";
			this->txtElemento->Size = System::Drawing::Size(100, 20);
			this->txtElemento->TabIndex = 11;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(8, 329);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(47, 13);
			this->label1->TabIndex = 12;
			this->label1->Text = L"Posicion";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(8, 369);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(43, 13);
			this->label2->TabIndex = 13;
			this->label2->Text = L"Palabra";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(8, 405);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 15;
			this->label3->Text = L"Numero";
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(66, 398);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(100, 20);
			this->txtNumero->TabIndex = 14;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(829, 449);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtElemento);
			this->Controls->Add(this->txtPosicion);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->txtUno);
			this->Controls->Add(this->btnEliminaruno);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->grilla2);
			this->Controls->Add(this->grilla1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				grilla1->RowCount=System::Convert::ToInt32(txtTamano->Text);
				grilla1->ColumnCount=2;
			 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
			 pilas.Guardar(grilla1);
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 pilas.Mostrar(grilla2);
		 }
private: System::Void btnEliminaruno_Click(System::Object^  sender, System::EventArgs^  e) {
			 int valor=System::Convert::ToInt32(txtUno->Text);
			 pilas.Eliminaruno(valor);
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			 int limite=System::Convert::ToInt32(txtTamano->Text);
			 pilas.Primos(limite);
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
			Nodo nodin;
			int posicion=System::Convert::ToInt32(txtPosicion->Text);
			nodin.Set_numero(System::Convert::ToInt32(txtNumero->Text));
			nodin.Set_nombre(marshal_as<std::string>(System::Convert::ToString(txtElemento->Text)));
			pilas.Insertaruno(posicion, nodin);
		 }
};
}

