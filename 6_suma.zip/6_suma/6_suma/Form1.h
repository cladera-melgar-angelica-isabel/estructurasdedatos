#pragma once


#include <iostream>
#include <string>
#include "Ej6_vector.h"
#include <msclr\marshal_cppstd.h>


namespace My6_suma {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;



	Ej6_vector objeto;
	int pos=0;




	/// <summary>
	/// Resumen de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::TextBox^  txtdato;
	private: System::Windows::Forms::Button^  btndefinir;
	private: System::Windows::Forms::Button^  btningresar;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::DataGridView^  grilla_dato;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->txtdato = (gcnew System::Windows::Forms::TextBox());
			this->btndefinir = (gcnew System::Windows::Forms::Button());
			this->btningresar = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->grilla_dato = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_dato))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(32, 38);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tamano";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(32, 76);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(30, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Dato";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(35, 121);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(0, 13);
			this->label3->TabIndex = 2;
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(90, 38);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(100, 20);
			this->txttamano->TabIndex = 3;
			// 
			// txtdato
			// 
			this->txtdato->Location = System::Drawing::Point(90, 76);
			this->txtdato->Name = L"txtdato";
			this->txtdato->Size = System::Drawing::Size(100, 20);
			this->txtdato->TabIndex = 4;
			// 
			// btndefinir
			// 
			this->btndefinir->Location = System::Drawing::Point(220, 34);
			this->btndefinir->Name = L"btndefinir";
			this->btndefinir->Size = System::Drawing::Size(75, 23);
			this->btndefinir->TabIndex = 5;
			this->btndefinir->Text = L"Definir";
			this->btndefinir->UseVisualStyleBackColor = true;
			this->btndefinir->Click += gcnew System::EventHandler(this, &Form1::btndefinir_Click);
			// 
			// btningresar
			// 
			this->btningresar->Location = System::Drawing::Point(220, 72);
			this->btningresar->Name = L"btningresar";
			this->btningresar->Size = System::Drawing::Size(75, 23);
			this->btningresar->TabIndex = 6;
			this->btningresar->Text = L"Ingresar";
			this->btningresar->UseVisualStyleBackColor = true;
			this->btningresar->Click += gcnew System::EventHandler(this, &Form1::btningresar_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(129, 121);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 7;
			this->button3->Text = L"Calcular";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// grilla_dato
			// 
			this->grilla_dato->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_dato->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, 
				this->Column2});
			this->grilla_dato->Location = System::Drawing::Point(38, 160);
			this->grilla_dato->Name = L"grilla_dato";
			this->grilla_dato->Size = System::Drawing::Size(244, 262);
			this->grilla_dato->TabIndex = 8;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Dato";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Promedio";
			this->Column2->Name = L"Column2";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(339, 434);
			this->Controls->Add(this->grilla_dato);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->btningresar);
			this->Controls->Add(this->btndefinir);
			this->Controls->Add(this->txtdato);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_dato))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			
			 int tam,t;
			 tam=System::Convert::ToInt32(txttamano->Text);
			 objeto.Set_tamano(tam);
			 grilla_dato->RowCount=objeto.Get_tamano();
			 /*objeto.Set_tamano(tam-2);
			 grilla_dato->RowCount=objeto.Get_tamano();
			 pos=0;*/
			 
			 
			 }
private: System::Void btningresar_Click(System::Object^  sender, System::EventArgs^  e) {

			 double elemento;
			 elemento=System::Convert::ToDouble(txtdato->Text);
			 if (objeto.Insertar(elemento,pos)) {
				pos++;
				// Despliegue del Vector
				grilla_dato->ColumnCount=2;
				grilla_dato->RowCount=objeto.Get_tamano();

				int i=0; double dato;
				for (i=0;i<objeto.Get_tamano();i++)
				{
				dato=objeto.Get_vector(i);
				grilla_dato->Rows[i]->Cells[0]->Value=System::Convert::ToDouble(dato);
				}

			 }
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {

			 /*int i;
			  double prom;
			  
			  for(int k=0;k<objeto.Get_tamano()-2;k++)
			  {
				  prom=(objeto.Get_vector(k)+objeto.Get_vector(k+1)+objeto.Get_vector(k+2))/3;
				  grilla_dato->Rows[k]->Cells[1]->Value=System::Convert::ToDouble(prom);
			  }
			 
			 */


			 Ej6_vector objeto1;
			objeto.Set_tamano(objeto.Get_tamano());
			 int  elemento, i=0;
			 double prom;
			 if(objeto.promedio(i,&prom))
			 {
				 for(i=0;i<objeto.Get_tamano()-2;i++)
				 {
				 objeto.promedio(i,&prom);
			
				 objeto1.Insertar(prom,i);
				 }
			 }


			    grilla_dato->ColumnCount=2;
				grilla_dato->RowCount=objeto.Get_tamano();

				i=0;double  dato;
				for (i=0;i<objeto.Get_tamano();i++)
				{
				dato=objeto1.Get_vector(i);
				grilla_dato->Rows[i]->Cells[1]->Value=System::Convert::ToDouble(dato);
				}


		 }//cierre
};
}

