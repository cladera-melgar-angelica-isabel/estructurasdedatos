#include "StdAfx.h"
#include "Ej6_vector.h"
#include <iostream>


#define m 15

using namespace std;


Ej6_vector::Ej6_vector(void)
{v[m]=0;
 tamano=0;
}
Ej6_vector::~Ej6_vector(void)
{
}

	bool Ej6_vector::promedio(int i,double *aux)
	{if(tamano<3)
	{return false;
	}
	else
	{
		*aux=0;
		*aux=(v[i]+v[i+1]+v[i+2])/3;
		return true;
	}
	}


	int Ej6_vector::Get_tamano()
	{return tamano;
	}
	void Ej6_vector::Set_tamano(int tam)
	{tamano=tam;
	}
	float Ej6_vector::Get_vector(int posicion)
	{return v[posicion];
	}
	void Ej6_vector::Set_vector(int posicion, double _elemento)
	{v[posicion]=_elemento;
	}
	

	
	bool Ej6_vector::Vacio_vector()
	{if (tamano==0) 
		{return true;}
	else 
	{return false;}	

	}
	bool Ej6_vector::Lleno_vector()
	{
		if (tamano==(m-1)) 
	    {return true;}

	else {return false;}

	}
	bool Ej6_vector::Insertar(double _elemento, int posicion)
	{if((posicion<0)&&(posicion>tamano))
	    {return false;}
	else
		{
		if(Lleno_vector()==true) 
			{return false;}
		else
			{	
			    int i=Get_tamano();
				while(i>posicion)
				{
				 v[i]=v[i-1];
				 i--;
				}
				v[posicion]=_elemento;
				//Incrementar();
				return true;
			}
		}

	}


	/*bool Ej6_vector::promedio(int _elemento, int posicion)
	{if((posicion<0)&&(posicion>tamano))
	    {return false;}
	else
	{

	}
	}*/
	