#pragma once

#define m 15

class Ej6_vector
{
private:
	double v[m];
	int tamano;
public:
	Ej6_vector(void);

	~Ej6_vector(void);


	bool promedio(int i,double *aux);

	int Get_tamano();
	void Set_tamano(int tam);
	float Get_vector(int posicion);
	void Set_vector(int posicion, double _elemento); 

	
	bool Vacio_vector();
	bool Lleno_vector();
	bool Insertar(double _elemento, int posicion);
	
	//bool promedio(int _elemento, int posicion);



};

