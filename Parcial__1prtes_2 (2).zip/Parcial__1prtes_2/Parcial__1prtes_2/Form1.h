#pragma once
#include "Parcial_1_2.h"//libreria importante
#include <string>
#include <iostream>
#include <msclr\marshal_cppstd.h>

namespace Parcial__1prtes_2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	using namespace std;
	using namespace msclr::interop;


	Parcial_1_2 objeto;//creacion de un objeto global
	int pos=0;//creacion de una variable global
	int pos1=0;


	/// <summary>
	/// Resumen de Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n utilizando.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txttamano;
	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtnombre;
	private: System::Windows::Forms::TextBox^  txtnota;
	private: System::Windows::Forms::Button^  btndefinir;
	private: System::Windows::Forms::Button^  btnnombre;
	private: System::Windows::Forms::Button^  btnnota;
	private: System::Windows::Forms::DataGridView^  grilla_dato;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataGridView^  grilla_obt;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;

	private:
		/// <summary>
		/// Variable del dise�ador requerida.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido del m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtnombre = (gcnew System::Windows::Forms::TextBox());
			this->txtnota = (gcnew System::Windows::Forms::TextBox());
			this->btndefinir = (gcnew System::Windows::Forms::Button());
			this->btnnombre = (gcnew System::Windows::Forms::Button());
			this->btnnota = (gcnew System::Windows::Forms::Button());
			this->grilla_dato = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->grilla_obt = (gcnew System::Windows::Forms::DataGridView());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_dato))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_obt))->BeginInit();
			this->SuspendLayout();
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(76, 42);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(100, 20);
			this->txttamano->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(13, 42);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"tamano";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 77);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Nombre";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 123);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(30, 13);
			this->label3->TabIndex = 3;
			this->label3->Text = L"Nota";
			// 
			// txtnombre
			// 
			this->txtnombre->Location = System::Drawing::Point(76, 77);
			this->txtnombre->Name = L"txtnombre";
			this->txtnombre->Size = System::Drawing::Size(100, 20);
			this->txtnombre->TabIndex = 4;
			// 
			// txtnota
			// 
			this->txtnota->Location = System::Drawing::Point(76, 116);
			this->txtnota->Name = L"txtnota";
			this->txtnota->Size = System::Drawing::Size(100, 20);
			this->txtnota->TabIndex = 5;
			// 
			// btndefinir
			// 
			this->btndefinir->Location = System::Drawing::Point(207, 38);
			this->btndefinir->Name = L"btndefinir";
			this->btndefinir->Size = System::Drawing::Size(75, 23);
			this->btndefinir->TabIndex = 6;
			this->btndefinir->Text = L"Definir";
			this->btndefinir->UseVisualStyleBackColor = true;
			this->btndefinir->Click += gcnew System::EventHandler(this, &Form1::btndefinir_Click);
			// 
			// btnnombre
			// 
			this->btnnombre->Location = System::Drawing::Point(207, 71);
			this->btnnombre->Name = L"btnnombre";
			this->btnnombre->Size = System::Drawing::Size(92, 31);
			this->btnnombre->TabIndex = 7;
			this->btnnombre->Text = L"Ingresar nombre";
			this->btnnombre->UseVisualStyleBackColor = true;
			this->btnnombre->Click += gcnew System::EventHandler(this, &Form1::btnnombre_Click);
			// 
			// btnnota
			// 
			this->btnnota->Location = System::Drawing::Point(207, 114);
			this->btnnota->Name = L"btnnota";
			this->btnnota->Size = System::Drawing::Size(92, 22);
			this->btnnota->TabIndex = 8;
			this->btnnota->Text = L"Ingresar nota";
			this->btnnota->UseVisualStyleBackColor = true;
			this->btnnota->Click += gcnew System::EventHandler(this, &Form1::btnnota_Click);
			// 
			// grilla_dato
			// 
			this->grilla_dato->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_dato->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, 
				this->Column2});
			this->grilla_dato->Location = System::Drawing::Point(25, 162);
			this->grilla_dato->Name = L"grilla_dato";
			this->grilla_dato->Size = System::Drawing::Size(239, 179);
			this->grilla_dato->TabIndex = 9;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Nombre";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"Nota";
			this->Column2->Name = L"Column2";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(372, 162);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 10;
			this->button1->Text = L"Obtener";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// grilla_obt
			// 
			this->grilla_obt->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->grilla_obt->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column3, this->Column4});
			this->grilla_obt->Location = System::Drawing::Point(294, 191);
			this->grilla_obt->Name = L"grilla_obt";
			this->grilla_obt->Size = System::Drawing::Size(240, 150);
			this->grilla_obt->TabIndex = 11;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"Nombre";
			this->Column3->Name = L"Column3";
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"Nota";
			this->Column4->Name = L"Column4";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(564, 392);
			this->Controls->Add(this->grilla_obt);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->grilla_dato);
			this->Controls->Add(this->btnnota);
			this->Controls->Add(this->btnnombre);
			this->Controls->Add(this->btndefinir);
			this->Controls->Add(this->txtnota);
			this->Controls->Add(this->txtnombre);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txttamano);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_dato))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->grilla_obt))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int t;//se crea la variable que va almacenar el valor de tamano
				 t=System::Convert::ToInt32(txttamano->Text);//el valor que se escribio en el textbox se lo covierte y se asigana a la variable 
				objeto.Set_tamano(t);//Se envia el parametro para que la clase lo tenga
				grilla_dato->RowCount=objeto.Get_tamano();//Aqui se define cuantas filas va a tener la gilla 


			 }
private: System::Void btnnota_Click(System::Object^  sender, System::EventArgs^  e) {

			 int nota;//se crea la variable para que almacene el valor 
			 nota=System::Convert::ToInt32(txtnota->Text);//se conviete lo que habia en el textbox 
			 
			 if(objeto.ingresar(pos1,nota))//se hace la pregunta si lo que se hizo en metodo ingresar es verdadero o falso
			 {
				 pos1++;//es ta es la variable global que se indico al principio, aqui aumenta de valor
				 grilla_dato->ColumnCount=2;//en la grilla hay dos columnas

				 int i=0;//se crea un contador, hay algunas cosas que saque que habia en el video por que no son escensiales, como dato1
				 for(i=0;i<objeto.Get_tamano();i++)
				 {
					 //esta parte es para que la nota que se ingreso se guarde en su lugar correspondiente de la grilla
					 grilla_dato->Rows[i]->Cells[1]->Value=System::Convert::ToInt32(objeto.Get_nota(i));
				 }
			 }
		 }
private: System::Void btnnombre_Click(System::Object^  sender, System::EventArgs^  e) {

			 string nomb;
			 nomb=marshal_as<string>(Convert::ToString(txtnombre->Text));
			
			  if(objeto.ingresarnom(pos,nomb))
			 {
				 pos++;
				 grilla_dato->ColumnCount=2;

				 int i=0;
				 string dato2;
				 for(i=0;i<objeto.Get_tamano();i++)
				 {
					 dato2=objeto.Get_nombre(i);
					 String^ aux=gcnew String(dato2.c_str());
					 grilla_dato->Rows[i]->Cells[0]->Value=aux;
				 }
			 }

			 


		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

			 objeto.ordenar();//Se pide que se ordene el vector 
			 grilla_obt->ColumnCount=2;// hay dos columnas
			 grilla_obt->RowCount=3;//cada columna va a tener 3 filas

			 string nom;
			 for(int i=0;i<3;i++)
			 {//se rellena la otra grilla con las tres mejores notas de los estudiantes
			 grilla_obt->Rows[i]->Cells[1]->Value=System::Convert::ToInt32(objeto.Get_nota(i));
			 nom=objeto.Get_nombre(i);
			String^ aux=gcnew String(nom.c_str());
			grilla_obt->Rows[i]->Cells[0]->Value=aux;
			 }

		 }
};
}

